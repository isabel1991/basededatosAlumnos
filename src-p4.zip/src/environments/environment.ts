// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyC9ydFTiRnsjV7NSq72Z158cjmPL8WMBCY",
    authDomain: "alumnos-9c8d6.firebaseapp.com",
    databaseURL: "https://alumnos-9c8d6.firebaseio.com",
    projectId: "alumnos-9c8d6",
    storageBucket: "alumnos-9c8d6.appspot.com",
    messagingSenderId: "61231086739",
    appId: "1:61231086739:web:efcf1b549472169339a166",
    measurementId: "G-GWSLG0QQXT"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
