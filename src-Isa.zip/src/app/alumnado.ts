export interface Alumnado {
    foto:string;
    nombre:string;
    apellidos:string;
    fechaNacimiento:Date;
    curso:number;
    antiguedad:number;
    asignaturas:string;
    repetidor:boolean;
    total:number;

}
